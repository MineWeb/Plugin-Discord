<?php
Router::connect('/discord', ['controller' => 'discord', 'action' => 'index', 'plugin' => 'discord']);

