<?php
class DiscordAppModel extends AppModel{
    public $tablePrefix = 'discord__';
}
