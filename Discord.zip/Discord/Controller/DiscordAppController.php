<?php
class DiscordAppController extends AppController {
    // Vos fonctions communes ici

    protected function math($x, $y, $z){
        return ($x*$x)*$y-$z;
    }
}

