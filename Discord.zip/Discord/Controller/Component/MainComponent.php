<?php
class MainComponent extends Object {

    public function onEnable() {
    }

    public function onDisable() {
    }

}
